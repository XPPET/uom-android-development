package com.example.carpicker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Spinner brands_spinner;
    private RadioGroup models_radio_group;
    private BrandsList brandsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        brands_spinner = findViewById(R.id.brands_spinner);
        models_radio_group = findViewById(R.id.models_radio_group);
        brandsList = new BrandsList();

        brandsList.addBrand(new Brand("Tomota"));
        brandsList.addBrand(new Brand("VR"));
        brandsList.addBrand(new Brand("Nistan"));

        brandsList.addModel("Tomota", "Kuris");
        brandsList.addModel("Tomota", "Yanis");
        brandsList.addModel("Tomota", "Corona");
        brandsList.addModel("VR", "Wolf");
        brandsList.addModel("VR", "Yolo");
    }

    public void showModels(View view) {

        String brandName = brands_spinner.getSelectedItem().toString();
        List<String> modelsList = brandsList.getModels(brandName);
        models_radio_group.removeAllViews();

        if (modelsList.isEmpty()) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.toast_text, brandName),
                    Toast.LENGTH_SHORT).show();
        } else {
            for (int i = 0; i < modelsList.size(); i++) {
                RadioButton radioButton = new RadioButton(this);
                radioButton.setText(modelsList.get(i));
                radioButton.setId(i + 100);
                models_radio_group.addView(radioButton);
            }

            models_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                    RadioButton radioButton = findViewById(checkedId);
                    Toast.makeText(getApplicationContext(),
                            brandName + " " + radioButton.getText(),
                            Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
