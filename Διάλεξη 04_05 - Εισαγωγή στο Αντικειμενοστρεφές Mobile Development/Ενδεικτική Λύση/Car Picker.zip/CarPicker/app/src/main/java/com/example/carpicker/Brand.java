package com.example.carpicker;

import java.util.ArrayList;
import java.util.List;

public class Brand {

    private final String brandName;
    private final List<String> modelsList;

    public Brand(String brandName) {

        this.brandName = brandName;
        modelsList = new ArrayList<>();
    }

    public String getBrandName() {
        return brandName;
    }

    public List<String> getModels() {
        return modelsList;
    }

    public void addModel(String model) {
        modelsList.add(model);
    }
}
