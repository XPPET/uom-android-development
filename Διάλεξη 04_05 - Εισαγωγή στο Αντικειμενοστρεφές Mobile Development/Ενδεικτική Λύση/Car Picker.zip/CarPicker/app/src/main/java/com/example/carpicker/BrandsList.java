package com.example.carpicker;

import java.util.ArrayList;
import java.util.List;

public class BrandsList {

    private final List<Brand> brandsList;

    public BrandsList() {
        brandsList = new ArrayList<>();
    }

    public void addBrand(Brand brand) {
        brandsList.add(brand);
    }

    public void addModel(String brandName, String model) {
        for (Brand brand: brandsList)
            if (brand.getBrandName().equals(brandName))
                brand.addModel(model);
    }

    public List<String> getModels(String brandName) {
        for (Brand brand: brandsList)
            if (brand.getBrandName().equals(brandName))
                return brand.getModels();
        return null;
    }
}
