package com.example.carpickersqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Spinner brands_spinner;
    private RadioGroup models_radio_group;
    private BrandsList brandsList;
    private SQLiteConnection dbConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        brands_spinner = findViewById(R.id.brands_spinner);
        models_radio_group = findViewById(R.id.models_radio_group);
        brandsList = new BrandsList(getAssets());
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                brandsList.getAllBrandNames());
        brands_spinner.setAdapter(arrayAdapter);
        dbConnection = new SQLiteConnection(this);
    }

    public void showModels(View view) {

        String brandName = brands_spinner.getSelectedItem().toString();
        List<String> modelsList = brandsList.getModels(brandName);
        models_radio_group.removeAllViews();

        if (modelsList.isEmpty()) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.toast_text, brandName),
                    Toast.LENGTH_SHORT).show();
        } else {
            for (int i = 0; i < modelsList.size(); i++) {
                RadioButton radioButton = new RadioButton(this);
                radioButton.setText(modelsList.get(i));
                radioButton.setId(i + 100);
                models_radio_group.addView(radioButton);
            }

            models_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                    RadioButton radioButton = findViewById(checkedId);
                    String model = radioButton.getText().toString();
                    long newRowId = dbConnection.insert(brandName, model);
                    Toast.makeText(getApplicationContext(),
                            "User selection " + brandName + " " + model + " inserted at row " + newRowId,
                            Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
