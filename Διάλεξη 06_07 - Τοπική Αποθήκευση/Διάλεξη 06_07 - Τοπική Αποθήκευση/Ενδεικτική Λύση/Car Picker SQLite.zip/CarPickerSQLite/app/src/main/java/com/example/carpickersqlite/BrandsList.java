package com.example.carpickersqlite;

import android.content.res.AssetManager;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class BrandsList {

    private final List<Brand> brandsList;

    public BrandsList(AssetManager assets) {
        brandsList = new ArrayList<>();

        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = dbFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(assets.open("records.xml"));
            Element element = document.getDocumentElement();
            element.normalize();

            NodeList carBrandsList = document.getElementsByTagName("carBrand");
            for (int i = 0; i < carBrandsList.getLength(); i++) {
                Node carBrand = carBrandsList.item(i);
                if (carBrand.getNodeType() == Node.ELEMENT_NODE) {
                    NodeList nameNodeList = ((Element) carBrand).getElementsByTagName("name");
                    NodeList nameNodeChildren = nameNodeList.item(0).getChildNodes();
                    String brandName = nameNodeChildren.item(0).getTextContent().trim();

                    NodeList modelsNodeList = ((Element) carBrand).getElementsByTagName("models");
                    if (modelsNodeList.getLength() > 0 && modelsNodeList.item(0) != null) {
                        NodeList modelsNodeChildren = modelsNodeList.item(0).getChildNodes();
                        String models = modelsNodeChildren.item(0).getTextContent().trim();
                        addBrand(new Brand(brandName, models));
                    } else {
                        addBrand(new Brand(brandName));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addBrand(Brand brand) {
        brandsList.add(brand);
    }

    public List<String> getAllBrandNames() {
        List<String> brands = new ArrayList<>();
        for (Brand brand: brandsList)
            brands.add(brand.getBrandName());
        return brands;
    }

    public List<String> getModels(String brandName) {
        for (Brand brand: brandsList)
            if (brand.getBrandName().equals(brandName))
                return brand.getModels();
        return null;
    }
}
