package com.example.carpickersqlite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Brand {

    private final String brandName;
    private final List<String> modelsList;

    public Brand(String brandName) {

        this.brandName = brandName;
        modelsList = new ArrayList<>();
    }

    public Brand(String brandName, String models) {

        this.brandName = brandName;
        modelsList = Arrays.asList(models.split(","));
    }

    public String getBrandName() {
        return brandName;
    }

    public List<String> getModels() {
        return modelsList;
    }
}
