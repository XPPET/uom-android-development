package com.example.carpickersqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.Date;

public class SQLiteConnection {

    private SelectionLoggerDbHelper dbHelper;
    private SQLiteDatabase db;

    public SQLiteConnection(Context context) {

        dbHelper = new SelectionLoggerDbHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public long insert(String brand, String model) {

        ContentValues values = new ContentValues();
        values.put(SelectionLogger.LoggerEntry.COLUMN_NAME_BRAND, brand);
        values.put(SelectionLogger.LoggerEntry.COLUMN_NAME_MODEL, model);
        values.put(SelectionLogger.LoggerEntry.COLUMN_NAME_TIMESTAMP,
                new Date(System.currentTimeMillis()).toString());

        long newRowId = db.insert(SelectionLogger.LoggerEntry.TABLE_NAME, null, values);
        return newRowId;
    }

    public void close() {

        db.close();
    }
}
