package com.example.carpickermysql;

import java.util.ArrayList;
import java.util.List;

public class BrandsList {

    private List<Brand> brandsList;

    public BrandsList(String ip) {

        brandsList = new ArrayList<>();
        String url= "http://" + ip + "/carsDBServices/populateDropDown.php";

        try {
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            brandsList = okHttpHandler.getCarData(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<String> getAllBrandNames() {

        List<String> brands = new ArrayList<>();
        for (Brand brand: brandsList)
            brands.add(brand.getBrandName());
        return brands;
    }

    public List<String> getModels(String brandName) {

        for (Brand brand: brandsList)
            if (brand.getBrandName().equals(brandName))
                return brand.getModels();
        return null;
    }
}
